﻿//FileName: SplashForm.cs
//FileType: Visual C# Source file
//Author: Junghwan Yang
//Student ID: 200320739
//Created On: 28/02/2017
//Copy Rights: Junghwan Yang
//Description: This app shows the logo of Movie Bonanza.

/////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieBonanza
{
    public partial class SplashForm : Form
    {
        //CONSTRUCTORS------------------------
        public SplashForm()
        {
            InitializeComponent();
        }
    }
}
